package com.modulefive.projecttwo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

/**
*
* This interface implements the DAO for the weight table. Letting us interact with it.
* This interface is essential for displaying our weights in a grid.
*
* */

@Dao
public interface WeightDao {
    @Insert
    void insertWeight(WeightEntry entry);
    @Update
    void updateWeight(WeightEntry entry);
    @Delete
    void deleteWeight(WeightEntry entry);

    // Get all weights for a specific user, ordered by date
    @Query("SELECT * FROM weights WHERE user_id = :username ORDER BY date DESC")
    List<WeightEntry> getWeightsForUser(String username);
}
