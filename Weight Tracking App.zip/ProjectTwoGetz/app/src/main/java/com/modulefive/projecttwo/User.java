package com.modulefive.projecttwo;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
*
* Creates the users table with columns; id, username, password
* This is the main table in our database, the other two tables are connected to this table via
*   foreign keys.
* This class also implements setter and getter methods for password and username.
*
 *
 * This class used the Gemini ask feature built into android studio to explain how to use a room
 * database, create the DAO for it and connect it to the app database java file.
 * PROMPT: "How to I add the logic to use my database for the login page. What files do I need. Help
 * Guide me by explaining how each part works."
 *
* */

@Entity(tableName = "users", indices = {@Index(value = {"username"}, unique = true)})
public class User {

    public User(@NonNull String username, @NonNull String password) {
        this.username = username;
        this.password = password;
    }

    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    @ColumnInfo(name = "username")
    public String username;

    @NonNull
    @ColumnInfo(name = "password")
    public String password;

    @NonNull
    public String getUsername() {return username;}
    public void setUsername(@NonNull String username) {this.username = username;}
    public String getPassword() {return password;}
    public void setPassword(String password) {this.password = password;}

}
