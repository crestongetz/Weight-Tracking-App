package com.modulefive.projecttwo;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

/**
* This interface implements the DAO for the goal database
* It lets us interact and change the users goal weight
* */

@Dao
public interface GoalDao {
    @Query("SELECT * FROM goals WHERE user_id = :userId LIMIT 1")
    GoalEntry getGoalForUser(String userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOrUpdateGoal(GoalEntry goal);
}
