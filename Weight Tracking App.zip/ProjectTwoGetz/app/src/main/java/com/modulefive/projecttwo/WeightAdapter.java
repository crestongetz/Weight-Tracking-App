package com.modulefive.projecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/**
*
* This java class creates the logic we need to show the weight data onto our grid.
* It acts as an intermediate between the weights table and our UI.
* We are storing a list of Weight Entries in the list weightsList which is then used to
* populate our grid. The class also implements the logic for users to edit and delete each card or weight
* entry. And
*
* */

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {
    private List<WeightEntry> weightsList; //local weights list, helps change the grid
    private OnWeightActionListener listener;

    private String formattedGetWeight;

    public interface OnWeightActionListener {
        void onDelete(WeightEntry entry);
        void onEdit(WeightEntry entry);
    }

    public WeightAdapter(List<WeightEntry> weightsList, OnWeightActionListener listener) {
        this.weightsList = weightsList;
        this.listener = listener;
    }

    @NonNull
    @Override
    //Creates the actual card to display on grid. XML -> Java code
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new WeightViewHolder(view);
    }

    //This is an essential method for displaying out data
    //This method formats each data and weight, and it sets up the delete and edit buttons.
    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightsList.get(position);

        // Convert Milliseconds to Human Readable Date
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        String dateString = sdf.format(new Date(entry.getDate()));

        //Format output
        formattedGetWeight = entry.getWeight() + " lbs";
        holder.textWeight.setText(formattedGetWeight);
        holder.textDate.setText(dateString);

        //Delete button
        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDelete(entry);
            }
        });

        //Lets users edit upon clicking on the card
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onEdit(entry);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onDelete(entry);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return weightsList.size();
    }

    // refresh the grid when data changes
    public void updateData(List<WeightEntry> newWeights) {
        this.weightsList = newWeights;
        notifyDataSetChanged();
    }

    //Speeds up app, this method stores references to textView and buttons
    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textWeight, textDate;
        Button deleteButton;
        WeightViewHolder(View v) {
            super(v);
            textWeight = v.findViewById(R.id.text_weight);
            textDate = v.findViewById(R.id.text_date);
            deleteButton = v.findViewById(R.id.deleteButton);
        }
    }

}
