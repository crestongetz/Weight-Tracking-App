package com.modulefive.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import android.view.View;

/**
*
* This is the main display java class. It implements the core logic of the app.
* Here users can create, delete, update, and read their weights they have entered.
* They can also add a goal weight they hope to reach.
* In the top right their is a settings icon which leads to the settings page.
* In the settings pages users can enable or diable sms goal weight notifications and log out.
* When a user logs out it will take the back to the login page.
*
* User can scroll to view their past weights
* TODO: At some point a limit should be added to the number of cards added or the app will become slow
*
* Users can click on each card and edit the weight for that entry. Full CRUD operations
 *
 * Similar to the login page the Gemini agent feature built into android studio was used to build upon
 * the UI I already built for the grid and weight inputs. I also used it to help me with sending the
 * text message: see SnsNotifications.java.
 *
*
* */

public class MainDisplay extends AppCompatActivity {

    private WeightAdapter adapter;
    private AppDatabase db;
    private String currentUsername;
    private List<WeightEntry> weightsList = new ArrayList<>();
    private TextView emptyStateText;
    private EditText goalWeightInput;
    private TextView userWelcomeText;
    private String welcomeString; //used to avoid concatenation

    private static final String PREFS_NAME = "AppPrefs";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_display);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = AppDatabase.getDatabase(this);

        // Get the username passed from MainActivity
        currentUsername = getIntent().getStringExtra("USERNAME");
        //if no username throw error
        if (currentUsername == null || currentUsername.isEmpty()) {
            Toast.makeText(this, "Error: No user logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        //Get ids from XML for use
        RecyclerView weightGrid = findViewById(R.id.weightGrid);
        EditText weightInput = findViewById(R.id.editWeight);
        Button addButton = findViewById(R.id.enterWeightButton);
        emptyStateText = findViewById(R.id.emptyStateText);
        ImageButton settingsButton = findViewById(R.id.settingsButton);
        goalWeightInput = findViewById(R.id.editGoalWeight);
        Button updateGoalButton = findViewById(R.id.goalWeightButton);
        userWelcomeText = findViewById(R.id.userWelcomeText);

        AppDatabase.databaseWriteExecutor.execute(() -> {
            updateWelcomeText(); 
        });

        weightGrid.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new WeightAdapter(weightsList, new WeightAdapter.OnWeightActionListener() {
            @Override
            public void onDelete(WeightEntry entry) {
                AppDatabase.databaseWriteExecutor.execute(() -> {
                    db.weightDao().deleteWeight(entry);
                    runOnUiThread(() -> refreshData());
                });
            }

            @Override
            public void onEdit(WeightEntry entry) {
                showEditDialog(entry);
            }
        });
        weightGrid.setAdapter(adapter);

        refreshData();


        addButton.setOnClickListener(v -> { //adds data to db when user inputs weight
            String val = weightInput.getText().toString();
            if (!val.isEmpty()) {
                try {
                    double weight = Double.parseDouble(val);
                    long now = System.currentTimeMillis();

                    WeightEntry entry = new WeightEntry(currentUsername, weight, now);
                    AppDatabase.databaseWriteExecutor.execute(() -> {
                        db.weightDao().insertWeight(entry);
                        runOnUiThread(() -> {
                            weightInput.setText("");
                            refreshData();
                            checkGoalReached(weight);
                        });
                    });
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                }
            }
        });


        updateGoalButton.setOnClickListener(v -> {
            String val = goalWeightInput.getText().toString();
            if (!val.isEmpty()) {
                try {
                    double goalWeight = Double.parseDouble(val);
                    GoalEntry goal = new GoalEntry(currentUsername, goalWeight);
                    AppDatabase.databaseWriteExecutor.execute(() -> {
                        db.goalDao().insertOrUpdateGoal(goal);
                        runOnUiThread(() -> {
                            Toast.makeText(this, "Goal weight updated!", Toast.LENGTH_SHORT).show();
                            updateWelcomeText();
                        });
                    });
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });


        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainDisplay.this, SmsNotifications.class);
            intent.putExtra("USERNAME", currentUsername);
            startActivity(intent);
        });
    }

    // This method updates text with the current username and goal weight
    private void updateWelcomeText() {
        GoalEntry currentGoal = db.goalDao().getGoalForUser(currentUsername);
        runOnUiThread(() -> {
            String goalText = (currentGoal != null) ? currentGoal.getGoalWeight() + " lbs" : "-- lbs";
            welcomeString = "Hello " + currentUsername + "! Your goal: " + goalText;
            userWelcomeText.setText(welcomeString);
            if (currentGoal != null) {
                goalWeightInput.setText(String.valueOf(currentGoal.getGoalWeight()));
            }
        });
    }

    //This method will check if the user has reached their goal weight and if SMS is enabled
    private void checkGoalReached(double currentWeight) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            GoalEntry goal = db.goalDao().getGoalForUser(currentUsername);
            if (goal != null && currentWeight <= goal.getGoalWeight()) {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                if (prefs.getBoolean("sms_enabled_" + currentUsername, false)) {
                    runOnUiThread(() -> sendSmsNotification(goal.getGoalWeight()));
                }
            }
        });
    }

    //This method will send a sms notification to the user
    private void sendSmsNotification(double goalWeight) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 102);
            return;
        }

        try {
            String phoneNumber = "5555215554"; //TODO: number we are sending from
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Congrats " + currentUsername + "! You have reached your goal weight of " + goalWeight + "!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("SMS", "Failed to send SMS", e);
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
        }
    }

    //This method lets user edit each weight card
    private void showEditDialog(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(entry.getWeight()));
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String val = input.getText().toString();
            if (!val.isEmpty()) {
                try {
                    double newWeight = Double.parseDouble(val);
                    entry.setWeight(newWeight);
                    AppDatabase.databaseWriteExecutor.execute(() -> {
                        db.weightDao().updateWeight(entry);
                        runOnUiThread(() -> {
                            refreshData();
                            checkGoalReached(newWeight);
                        });
                    });
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // This method is very important
    // It will fetch the new weights in the database so we can display them.
    // It helps us determine if the grid is empty. And it lets us update the grid depending on user action
    private void refreshData() {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            weightsList = db.weightDao().getWeightsForUser(currentUsername);
            runOnUiThread(() -> {
                adapter.updateData(weightsList);

                if (weightsList.isEmpty()) { //if the user has no weights added, show empty grid
                    emptyStateText.setVisibility(View.VISIBLE);
                } else {
                    emptyStateText.setVisibility(View.GONE);
                }
            });
        });
    }
}
