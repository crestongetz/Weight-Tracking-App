package com.modulefive.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.materialswitch.MaterialSwitch;

/**
*
* This class creates the logic for us to send sms notifications to the user.
* The app will work without this functionality. And a text will only be sent if
*   the user had turned on the setting.
*
* This file also handles the logout button. If we were to expand our settings page we
*   may want to separate that logic
*
* User preferences will stay even if the app is closed.
 *
 * The Gemini agent feature was used to create and explain the on create method and the
 * sms logic for this class. It also helped created the xml layout for the settings page
 * PROMPT used: "The user should be able to click a settings icon at the
 * top right of the main display screen, in this page there should be a back button taking the user
 * back to the main display screen, a logout button that will take the user back to the login page,
 * and the toggle where the user can endable or disable sms notifications. The sms permissions should be
 * disabled by default, it should save its state depending on the user that is currently logged into
 * the app. A sms notification should get the users phone number without their input, and send them
 * a text message when their hit their goal weight or lower. See the logic I have already made and
 * build upon it. Explain each step."
 * PROMPT 2: "How do I get the phone number of the phone so I can send a text?"
 *
*
* */

public class SmsNotifications extends AppCompatActivity {

    private MaterialSwitch smsSwitch;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "AppPrefs";
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notifications);

        currentUsername = getIntent().getStringExtra("USERNAME");
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        smsSwitch = findViewById(R.id.smsSwitch);
        Button logoutButton = findViewById(R.id.logoutButton);
        ImageButton backButton = findViewById(R.id.backButton);

        // Load the saved state using a user-specific key
        boolean isSmsEnabled = sharedPreferences.getBoolean(getSmsKey(), false);
        smsSwitch.setChecked(isSmsEnabled);

        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    saveSmsPreference(true);
                    Toast.makeText(this, "Notifications Enabled!", Toast.LENGTH_SHORT).show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 101);
                }
            } else {
                saveSmsPreference(false);
                Toast.makeText(this, "Notifications Disabled", Toast.LENGTH_SHORT).show();
            }
        });

        //This is a clicklistener for the logout button. When pressed it will end the main display
        //activity and send users to the login page.
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(SmsNotifications.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        //Back button will send users back to main screen
        backButton.setOnClickListener(v -> {
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    //Gets a key for each user, so if two users are using the same phone their settings will
    //not interfere with each-other.
    private String getSmsKey() {
        return "sms_enabled_" + currentUsername;
    }

    //Saves if the user has sms toggled or not
    private void saveSmsPreference(boolean enabled) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(getSmsKey(), enabled);
        editor.apply();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPreference(true);
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Notifications Disabled", Toast.LENGTH_LONG).show();
                saveSmsPreference(false);
                if (smsSwitch != null) {
                    smsSwitch.setChecked(false);
                }
            }
        }
    }
}
