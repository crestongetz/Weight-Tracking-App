package com.modulefive.projecttwo;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * This class implements the apps database using room database
 * It lets us create and use our three tables
 * This class acts as the main controller for our storage
 *
 * Our app database has three tables: users, weights, and goals
 *
 * TODO: We are storing passwords in plainText
 *
 * This class used the Gemini ask feature built into android studio to explain how to use a room
 * database. It also helped me use background threads in other parts of the app.
 * PROMPT 1: "Move DB operations to background threads. My app uses main thread now. Explain how I can
 * speed up my app with background threads."
 * PROMPT 2:
 *
 */

//Everytime we need to change data structure we need to change version number
//When we change this all data will be removed from the database
//In a production environment we would need to find a way to keep user data
@Database(entities = {User.class, WeightEntry.class, GoalEntry.class}, version = 6)
public abstract class AppDatabase extends RoomDatabase {
    //The Dao's let us run our SQL queries.
    public abstract UserDao userDao();
    public abstract WeightDao weightDao();
    public abstract GoalDao goalDao();

    //We can wrap our queries with this so they run on background thread
    public static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(4);

    //One connection to database at a time. Helps reduce memory cost
    private static AppDatabase INSTANCE;

    public static synchronized AppDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                    AppDatabase.class, "user_db")
                    .allowMainThreadQueries() // Change to background thread in production
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;

    }

}
