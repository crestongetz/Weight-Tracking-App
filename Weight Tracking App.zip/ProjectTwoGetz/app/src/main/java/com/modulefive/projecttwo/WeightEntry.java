package com.modulefive.projecttwo;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;


/**
 *
 * This java class creates the weights table that will be shown on our grid. Its a Room entity class.
 * It handles the relationship between java and our SQL database. And defines weights table structure.
 * The weights table has columns; id, user_id, weight, and date.
 * We are using the users username for the primary and foreign key to connect to the users table
 *
 * */

@Entity(tableName = "weights",
        foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "username",
                childColumns = "user_id",
                onDelete = ForeignKey.CASCADE))
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    @ColumnInfo(name = "user_id")
    private String userId;

    private double weight;
    private long date;

    public WeightEntry(@NonNull String userId, double weight, long date) {
        this.userId = userId;
        this.weight = weight;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    @NonNull
    public String getUserId() { return userId; }
    public void setUserId(@NonNull String userId) { this.userId = userId; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public long getDate() { return date; }
    public void setDate(long date) { this.date = date; }
}
