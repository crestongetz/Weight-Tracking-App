package com.modulefive.projecttwo;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;


/**
* This class creates the goal weight table
* It lets us create the sqllite table in our app database class
* The columns are user_id and goal_weight
* We are using the users username for the primary and foreign key to connect to the users table
* */


@Entity(tableName = "goals",
        foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "username",
                childColumns = "user_id",
                onDelete = ForeignKey.CASCADE)) //if user is deleted their goal weight will also
public class GoalEntry {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "user_id")
    private String userId;

    @ColumnInfo(name = "goal_weight")
    private double goalWeight;

    public GoalEntry(@NonNull String userId, double goalWeight) {
        this.userId = userId;
        this.goalWeight = goalWeight;
    }

    @NonNull
    public String getUserId() { return userId; }
    public void setUserId(@NonNull String userId) { this.userId = userId; }

    public double getGoalWeight() { return goalWeight; }
    public void setGoalWeight(double goalWeight) { this.goalWeight = goalWeight; }
}
