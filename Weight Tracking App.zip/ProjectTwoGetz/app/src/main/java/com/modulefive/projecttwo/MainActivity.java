package com.modulefive.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
*
* This java class is used for the login page
* It lets the user login or register
* We are using the activity_main.xml file which is used to create the UI for the login page
*
*  TODO: The forgot password text/button does not do anything
*   However for the sake of our app we do not need to add it yet
*
* When the user wants to create a account a new screen will NOT be used. They can simply hit create
* account then login normally on the same page.
* Two users cannot have the same username.
*
* Users of the app can create new accounts on this page.
 *
 * This class used the Gemini agent feature built into android studio to improve the UI(XML) of the login
 * page. PROMPT: "Give the login page a more modern look and make it so the user can toggle seeing
 * their password. Explain each step, build upon what I have already done, make minimal changes.
 * A new user should still be able to create their account and login all on this page. Use a toast
 * message to notify them.
*
* */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES); //dark mode

        TextView loginTitle = findViewById(R.id.loginText);
        TextView instructionText = findViewById(R.id.instructionText);
        EditText usernameText = findViewById(R.id.usernameText);
        EditText passwordText = findViewById(R.id.passwordText);
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.newUserButton);

        //Click Listener for logging in
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameInput = usernameText.getText().toString();
                String passwordInput = passwordText.getText().toString();

                if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                AppDatabase db = AppDatabase.getDatabase(getApplicationContext());
                
                // Consistency fix: Move DB query to background thread
                AppDatabase.databaseWriteExecutor.execute(() -> {
                    User user = db.userDao().login(usernameInput, passwordInput);
                    
                    runOnUiThread(() -> {
                        if (user != null) { // successful login
                            Intent intent = new Intent(MainActivity.this, MainDisplay.class);
                            intent.putExtra("USERNAME", usernameInput);
                            startActivity(intent);
                            finish(); //End MainActivity
                        } else { // bad login
                            Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                        }
                    });
                });
            }
        });

        //Click Listener for creating a new user
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // UI Changes requested by user
                loginTitle.setText("Sign Up");
                instructionText.setVisibility(View.VISIBLE);
                
                String usernameInput = usernameText.getText().toString();
                String passwordInput = passwordText.getText().toString();

                // If fields are empty, we just show the prompt to the user
                if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter credentials then hit Create New User again", Toast.LENGTH_SHORT).show();
                    return;
                }

                AppDatabase db = AppDatabase.getDatabase(getApplicationContext());
                User newUser = new User(usernameInput, passwordInput);

                // Save to DB
                AppDatabase.databaseWriteExecutor.execute(() -> {
                    try {
                        db.userDao().registerUser(newUser);
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "User Registered! Now Login.", Toast.LENGTH_SHORT).show();
                            // Reset UI state after successful registration
                            loginTitle.setText("Login");
                            instructionText.setVisibility(View.GONE);
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Username already taken", Toast.LENGTH_SHORT).show());
                    }
                });
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
}
