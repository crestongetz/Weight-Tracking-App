package com.modulefive.projecttwo;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 *
 * This interface implements the DAO for the user database
 * It lets us add users to the database with the sql query below.
 *
 * */

@Dao
public interface UserDao {
    @Insert
    void registerUser(User user);

    @Query("SELECT * FROM users WHERE username = :name AND password = :pass") // Be mindful of SQL injection
    User login(String name, String pass);

}

